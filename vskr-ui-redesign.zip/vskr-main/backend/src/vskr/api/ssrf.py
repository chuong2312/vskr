"""Input URL checks before yt-dlp resolves or downloads a remote source."""

from __future__ import annotations

import ipaddress
import socket
from urllib.parse import urlsplit

from fastapi import HTTPException


def validate_ingest_url(url: str) -> str:
    parsed = urlsplit(url)
    if parsed.scheme.lower() not in {"http", "https"} or not parsed.hostname:
        raise HTTPException(400, "URL video phải bắt đầu bằng http:// hoặc https://.")
    if parsed.username is not None or parsed.password is not None:
        raise HTTPException(400, "URL video không được chứa thông tin đăng nhập.")
    try:
        port = parsed.port or (443 if parsed.scheme.lower() == "https" else 80)
    except ValueError as exc:
        raise HTTPException(400, "Cổng trong URL không hợp lệ.") from exc
    if not 1 <= port <= 65535:
        raise HTTPException(400, "Cổng trong URL không hợp lệ.")

    host = parsed.hostname.rstrip(".")
    try:
        literal = ipaddress.ip_address(host)
        addresses = [literal]
    except ValueError:
        try:
            records = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
            addresses = list({ipaddress.ip_address(record[4][0].split("%", 1)[0]) for record in records})
        except (OSError, ValueError) as exc:
            raise HTTPException(400, "Không thể phân giải máy chủ trong URL video.") from exc
    if not addresses:
        raise HTTPException(400, "Máy chủ trong URL video không có địa chỉ IP hợp lệ.")
    for address in addresses:
        checked = address.ipv4_mapped if isinstance(address, ipaddress.IPv6Address) and address.ipv4_mapped else address
        if not checked.is_global:
            raise HTTPException(400, "URL video trỏ tới địa chỉ mạng nội bộ hoặc không công khai.")
    return url
