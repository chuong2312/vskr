"""VSKR test suite."""
