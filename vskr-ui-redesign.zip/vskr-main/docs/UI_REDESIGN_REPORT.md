# VSKR — Báo cáo vòng làm lại giao diện

## Phạm vi đã sửa

- `web/user/index.html`, `web/user/styles.css`, `web/user/app.js`, `web/user/sw.js` (cache shell tăng lên v4)
- `web/admin/index.html`, `web/admin/admin.css`, `web/admin/admin.js`
- `tests/test_user_bundle.py`, `docs/ACCESS_MATRIX.md`, `README.md`
- `web/shared/tokens.css` được giữ nguyên vì token gốc đã đáp ứng màu sáng/tối; giao diện mới tái sử dụng các biến này.

## Hành vi giao diện đã bổ sung

### Người học

- Bố cục hội thoại và sân khấu video; thư viện chuyển thành drawer.
- Tìm kiếm phía trình duyệt trên danh sách video/tài liệu, giới hạn 8 kết quả, hỗ trợ phím mũi tên/Enter/Escape.
- Nút mở/đóng thư viện, đóng bằng Escape hoặc click bên ngoài.
- Cuộc hỏi mới chỉ xóa thread trong bộ nhớ trang.
- Lượt người dùng, trạng thái chờ và lượt trả lời; giới hạn 30 lượt người dùng gần nhất.
- Chip trích dẫn mở nguồn tương ứng; danh sách nguồn nằm trong `details` đóng mặc định.
- Gợi ý câu hỏi chèn vào ô nhập, không tự gửi.
- Enter gửi, Shift+Enter xuống dòng, bỏ qua Enter trong IME; textarea tự giãn đến 6 dòng.
- Điều hướng bài giảng trước/sau; nút chỉ hoạt động khi có nhiều hơn một video.
- Timeline và chức năng nhảy video/tài liệu gốc được giữ.
- Liên kết Quản trị công khai `/admin/login`; khi đã đăng nhập, JS hiện link `/admin` trên chính liên kết đó.

### Quản trị

- Sidebar navy, điều hướng bằng các `data-page` hiện có, responsive thành drawer dưới 900px.
- Các màn hiện có được giữ nguyên chức năng trong khung nội dung.
- Màn Học liệu có tab lọc loại, lọc tiêu đề/trạng thái, bảng responsive và dialog thêm học liệu.
- Dữ liệu ngày thêm không hiển thị vì `/api/library` hiện không trả trường thời gian.
- Giữ nguyên ID form, thao tác thử lại/xóa, xác nhận xóa, fetch và CSRF.

## ID mới

Người học: `library-search`, `search-results`, `drawer-toggle`, `new-thread`, `thread`, `thread-bottom`, `suggest-toggle`, `suggestions`, `prev-video`, `video-position`, `next-video`.

Quản trị: `admin-menu-toggle`, `open-add-library`, `close-add-library`, `add-library-dialog`, `library-filter-title`, `library-filter-status`, `apply-library-filter`, `count-all`, `count-video`, `count-document`.

Không đổi các ID cũ đang được JS sử dụng.

## Giả định và giới hạn

- `/api/library` trả danh sách dạng mảng; đã kiểm tra trực tiếp `handlers.library()`. Hàm này không trả `created_at`, nên không thêm cột ngày.
- `/api/catalog` tiếp tục được đọc qua các trường frontend đang dùng. Không sửa API.
- Hai ảnh tham chiếu được nhắc trong yêu cầu không có trong ZIP/tệp đính kèm thực tế ở phiên này. Bản dựng dựa trên mô tả layout bằng chữ, không thể đối chiếu pixel.
- Chưa có kiểm tra bằng trình duyệt thật trong môi trường này. Cần làm checklist thủ công ở kích thước 1440×900, 1024×768, 390×844 và cả sáng/tối.

## Kiểm tra đã chạy

- `node --check web/user/app.js` — đạt.
- `node --check web/admin/admin.js` — đạt.
- `PYTHONPATH=backend/src pytest -q` — 96 passed, 8 subtests passed.

`pytest -q` không có `PYTHONPATH` không tìm thấy package `vskr`; khi chạy từ thư mục dự án trong môi trường không cài editable, dùng `PYTHONPATH=backend/src pytest -q` hoặc kích hoạt `.venv` theo README.

## Checklist kiểm tra thủ công

- [ ] 1440×900, sáng: người học, drawer, tìm kiếm, player, timeline, nguồn, gửi câu hỏi.
- [ ] 1440×900, tối: tương phản, chip nguồn, textarea, trạng thái lỗi.
- [ ] 1024×768, sáng/tối: không tràn nội dung, bảng quản trị cuộn ngang.
- [ ] 390×844, sáng/tối: video sticky, thread cuộn riêng, composer không che nội dung.
- [ ] Drawer thư viện đóng bằng nút, Escape, click ngoài; focus trở lại nút mở.
- [ ] Tìm kiếm bằng bàn phím; chọn video và mở mục tài liệu.
- [ ] Câu hỏi thành công, ngoài phạm vi, 422, 429, 503 và ngoại tuyến.
- [ ] Chip [n] nhảy đúng mốc video hoặc mở đúng mục tài liệu.
- [ ] Quản trị: đăng nhập/đăng xuất, điều hướng, thêm URL/file video, thêm tài liệu, theo dõi job, thử lại và xóa.
- [ ] Quản trị: kiểm tra lọc loại, tiêu đề, trạng thái; dialog đóng bằng nút và Escape.
- [ ] Cài PWA; xác nhận ngoại tuyến chỉ hiển thị shell, không cache API/video/tài liệu.

## Lệnh kiểm tra

```bash
node --check web/user/app.js
node --check web/admin/admin.js
PYTHONPATH=backend/src pytest -q
```
